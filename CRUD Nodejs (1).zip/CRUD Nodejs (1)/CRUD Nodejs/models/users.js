const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

// Khởi tạo ứng dụng Express
const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.json());

// Kết nối MongoDB
mongoose.connect('mongodb://localhost:27017/ProductManagement', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log('Connected to MongoDB'))
  .catch(err => console.log(err));

// Định nghĩa mô hình sản phẩm
const productSchema = new mongoose.Schema({
    ProductCode: { type: String, required: true },
    ProductName: { type: String, required: true },
    ProductDate: { type: Date, required: true },
    ProductOriginPrice: { type: Number, required: true },
    Quantity: { type: Number, required: true },
    ProductStoreCode: { type: String, required: true }
});

const Product = mongoose.model('Product', productSchema);

// Thêm sản phẩm
app.post('/products/add', async (req, res) => {
    const { ProductCode, ProductName, ProductDate, ProductOriginPrice, Quantity, ProductStoreCode } = req.body;

    try {
        const newProduct = new Product({
            ProductCode,
            ProductName,
            ProductDate,
            ProductOriginPrice,
            Quantity,
            ProductStoreCode
        });
        await newProduct.save();
        res.status(201).json(newProduct);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Lấy danh sách sản phẩm
app.get('/products', async (req, res) => {
    try {
        const products = await Product.find();
        res.status(200).json(products);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Xóa sản phẩm
app.delete('/products/delete/:id', async (req, res) => {
    try {
        const product = await Product.findById(req.params.id);
        if (!product) return res.status(404).json({ message: 'Product not found' });

        await product.remove();
        res.json({ message: 'Product deleted successfully' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

//server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
